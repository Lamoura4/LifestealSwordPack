CRIMSON LIFESTEAL SWORD — personal adaptation of Titles & Tools Scarlet Sword

Original Scarlet Sword pixel art belongs to the Titles & Tools creator. Do not redistribute without permission.

INSTALL: Put this ZIP into your Fabric instance resourcepacks folder and enable it.
SERVER PLUGIN: item-model: "lifesteal:lifesteal_sword"
TEST: /give @s minecraft:netherite_sword[minecraft:item_model="lifesteal:lifesteal_sword"] 1

This version intentionally uses Minecraft's built-in extruded sprite (thin 3D edge) rather than a large chunky cube model. The heart medallion is painted into the guard. It is not a separately sculpted 3D heart.

The original pack contains Scarlet Sword and Scarlet Blade; there is no entry literally named Crimson Sword. This is based on Scarlet Sword.
